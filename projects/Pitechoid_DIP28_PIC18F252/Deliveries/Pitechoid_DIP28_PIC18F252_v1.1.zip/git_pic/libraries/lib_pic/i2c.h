#ifndef LIB_PIC_I2C_H
#define LIB_PIC_I2C_H

/*****************************************************************************
* Includes
******************************************************************************/
#include <xc.h>

#include "hardware_profile.h"
#include "types.h"

/*****************************************************************************
* Enums
******************************************************************************/
typedef enum{
    I2C_BUS_1 = 0,
    I2C_BUS_2,
    I2C_BUS_3,
    I2C_BUS_4,
    I2C_BUS_5,
    I2C_BUS_6
}I2C_BUS;

typedef struct{
    I2C_BUS bus_id;
    u32 freq;
    u8 slave_or_master;  // 0 = slave, 1 = master
    u8 en_master_it;
    u8 en_slave_it;
    u8 slave_addr;
}I2C_CFG_t;


/*****************************************************************************
* Defines
******************************************************************************/
#define I2C_ACK                 0
#define I2C_NACK                1

#define I2C_ADDR_WR(addr)    ((u8)((addr) << 1))
#define I2C_ADDR_RD(addr)    ((u8)(((addr) << 1) | 0x01))

#define I2C_SLAVE       0
#define I2C_MASTER      1


/*****************************************************************************
* Prototypes
******************************************************************************/
result_t i2c_init       (const I2C_CFG_t *cfg);
result_t i2c_start      (I2C_BUS bus_id);
result_t i2c_rstart     (I2C_BUS bus_id);
result_t i2c_stop       (I2C_BUS bus_id);
result_t i2c_read       (I2C_BUS bus_id, u8 ack, u8 *data);
result_t i2c_write      (I2C_BUS bus_id, u8 data);
result_t i2c_send_ack   (I2C_BUS bus_id, u8 ack);
result_t i2c_wait_ack   (I2C_BUS bus_id);
result_t i2c_read_reg   (I2C_BUS bus_id, u8 dev_addr, u8 reg_addr, u8 *data);
result_t i2c_read_n_reg (I2C_BUS bus_id, u8 dev_addr, u8 reg_addr, u8 size, u8 *data);
result_t i2c_write_reg  (I2C_BUS bus_id, u8 dev_addr, u8 reg_addr, u8 data);
result_t i2c_write_n_reg(I2C_BUS bus_id, u8 dev_addr, u8 reg_addr, u8 size, u8 *data);

#endif
