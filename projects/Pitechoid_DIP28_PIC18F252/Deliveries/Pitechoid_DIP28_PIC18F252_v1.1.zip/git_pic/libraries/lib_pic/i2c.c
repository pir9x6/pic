/*****************************************************************************
* Includes
******************************************************************************/
#include "i2c.h"
#include "xc.h"
#include "hardware_profile.h"
#include "delays.h"
#include "log.h"
#include "types.h"


/*****************************************************************************
* Prototypes
******************************************************************************/
static result_t _wait_for_idle(I2C_BUS bus_id);


/*****************************************************************************
* Init I2C bus
******************************************************************************/
result_t i2c_init(const I2C_CFG_t *cfg)
{
    #if defined (_18F252) || defined (_18LF252)

        u32 i2c_brg = (GetSystemClock() / cfg->freq) - 1;
        if (i2c_brg > 255){
            return ERROR;
        }

        if (cfg->bus_id == I2C_BUS_1){
            // set module in i2c master mode
            SSPCON1bits.SSPM = 8;

            // Enables the serial port and configures the pins as the serial port pins
            SSPCON1bits.SSPEN = 1;

            // set i2c frequency
            SSPADD = (u8)i2c_brg;

            // Standard Speed mode (100 kHz)
            SSPSTATbits.SMP = 1;
        }
        else{
            return ERROR;
        }

    #elif defined (_18F26K42) || defined (_18F57Q43)

        if (cfg->bus_id == I2C_BUS_1){

            /* 7 bits, master mode */
            I2C1CON0 = 0x04;

            /* ACKDT = ACK, ACKCNT = NACK */
            I2C1CON1 = 0x80;

            /* clock source selection (MFINTOSC = 500kHz) */
            I2C1CLK = 3;

            I2C1CON2bits.FME = 1;   /* Fast mode */
            I2C1CON2bits.SDAHT = 0; /* SDA hold time of 300 ns */
            I2C1CON2bits.BFRET = 1; /* bus free time of 16 clock cycles */

            // Clear all interrupt flags
            I2C1PIR = 0;

            // Clear all error flags
            I2C1ERR = 0;

            // Enable I2C module
            I2C1CON0bits.EN = 1;
        }
        else{
            return ERROR;
        }

    #elif defined(__PIC24F__) || defined(__dsPIC33F__)

        u32 I2C_BRG = (GetSystemClock() / cfg->freq - GetSystemClock() / 10000000ul) - 1;
        if (I2C_BRG > 65535){
            return ERROR;
        }

        if (cfg->bus_id == I2C_BUS_1){

            // frequency
            I2C1BRG = (u16)I2C_BRG;
            I2C1ADD = 0;
            I2C1MSK = 0;

            // configure bus
            I2C1CON = 0;
            I2C1CONbits.SCLREL = 1;     /* Release SCLx clock */
            if (cfg->slave_or_master == I2C_SLAVE){
                I2C1ADD = cfg->slave_addr;   // 7 bit slave address
            }
            I2C1CONbits.I2CEN = 1;          // enable the I2C bus

            // it master
            if (cfg->en_master_it){
                _MI2C1IE = 1;
            }else{
                _MI2C1IE = 0;
            }
            _MI2C1IF = 0;

            // it slave
            if (cfg->en_slave_it){
                _SI2C1IE = 1;
            }else{
                _SI2C1IE = 0;
            }
            _SI2C1IF = 0;

            LOG_DEBUG("i2c bus 1 is initialized");
        }

        #ifdef _MI2C2IF
            else if (cfg->bus_id == I2C_BUS_2){
                /* GPIO configured as Open Drain */
                ODCAbits.ODCA2 = 1;
                ODCAbits.ODCA3 = 1;

                // frequency
                I2C2BRG = I2C_BRG;
                I2C2ADD = 0;
                I2C2MSK = 0;

                // configure bus
                I2C2CON = 0;
                I2C2CONbits.SCLREL = 1;        /* Release SCLx clock */
                if (cfg->slave_or_master == I2C_SLAVE){
                    I2C2ADD = cfg->slave_addr;      // 7 bit slave address
                }
                I2C2CONbits.I2CEN = 1;              // enable the I2C bus

                // it master
                if (cfg->en_master_it){
                    _MI2C2IE = 1;
                }else{
                    _MI2C2IE = 0;
                }
                _MI2C2IF = 0;

                // it slave
                if (cfg->en_slave_it){
                    _SI2C2IE = 1;
                }else{
                    _SI2C2IE = 0;
                }
                _SI2C2IF = 0;

                LOG_DEBUG("i2c bus 2 is initialized");
            }
        #endif

    #elif defined(__PIC32__)

        // Set the I2C baud rate
        actual_clk = I2CSetFrequency(I2C1, GetPeripheralClock(), cfg->freq);
        if ( abs(actual_clk-cfg->freq) > cfg->freq/10 )
        {
            return ERROR;
        }

        //Configure I2C
        I2CConfigure(I2C1, I2C_ENABLE_SLAVE_CLOCK_STRETCHING|I2C_ENABLE_HIGH_SPEED);

        // Enable the I2C bus
        I2CEnable(I2C1, TRUE);

    #else
        #error -- processor ID not specified in generic header file
    #endif

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//------------------------- Send start condition ------------------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_start(I2C_BUS bus_id)
{
    /* wait for the bus to be free */
    // if (_wait_for_idle(bus_id) != SUCCESS){
    //     return ERROR;
    // }

    #if defined (_18F252) || defined (_18LF252)

        if (bus_id == I2C_BUS_1){
            SSPCON2bits.SEN = 1;
            while (SSPCON2bits.SEN);
        }
        else{
            return ERROR;
        }

    #elif defined (_18F26K42) || defined (_18F57Q43)

        if (bus_id == I2C_BUS_1){
            I2C1CON0bits.S = 1;
            while (I2C1CON0bits.S);
        }
        else if (bus_id == I2C_BUS_2){
            I2C2CON0bits.S = 1;
            while (I2C2CON0bits.S);
        }
        else{
            return ERROR;
        }

    #elif defined(__PIC24F__) || defined(__dsPIC33F__)

        if (bus_id == I2C_BUS_1){

            I2C1CONbits.SEN = 1;        // Send the start condition
        }

        #ifdef _MI2C2IF
        else if (bus_id == I2C_BUS_2){

            I2C2CONbits.SEN = 1;        // Send the start condition
        }
        #endif

    #elif defined(__PIC32MX__)

        if (bus_id == I2C_BUS_1){
            StartI2C1();                // Send the start condition
            IdleI2C1();                 // Wait to complete
        }

    #else

        #error -- processor ID not specified in generic header file

    #endif

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//------------------------ Send restart condition -----------------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_rstart(I2C_BUS bus_id)
{
    /* wait for the bus to be free */
    if (_wait_for_idle(bus_id) != SUCCESS){
        return ERROR;
    }

    #if defined (_18F252) || defined (_18LF252)

        if (bus_id == I2C_BUS_1){
            SSPCON2bits.RSEN = 1;
            while (SSPCON2bits.RSEN);
        }
        else{
            return ERROR;
        }

    #elif defined (_18F26K42) || defined (_18F57Q43)

        if (bus_id == I2C_BUS_1){
            I2C1CON0bits.RSEN = 1;
            while (I2C1CON0bits.RSEN);
        }
        else if (bus_id == I2C_BUS_2){
            I2C2CON0bits.RSEN = 1;
            while (I2C2CON0bits.RSEN);
        }
        else{
            return ERROR;
        }

    #elif defined(__PIC24F__) || defined(__dsPIC33F__)

        if (bus_id == I2C_BUS_1){
            I2C1CONbits.RSEN = 1;        // Envoyer un Repeated Start Condition
        }

        #ifdef _MI2C2IF
        else if (bus_id == I2C_BUS_2){
            I2C2CONbits.RSEN = 1;        // Envoyer un Repeated Start Condition
        }
        #endif

    #elif defined(__PIC32MX__)

        RestartI2C1();      //Send the re start condition
        IdleI2C1();         //Wait to complete

    #else

        #error -- processor ID not specified in generic header file

    #endif

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//------------------------- Send of Not Acknowledge ---------------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_send_ack(I2C_BUS bus_id, u8 Ack)
{
    /* wait for the bus to be free */
    if (_wait_for_idle(bus_id) != SUCCESS){
        return ERROR;
    }

    #if defined (_18F252) || defined (_18LF252)

        SSPCON2bits.ACKDT = Ack;
        SSPCON2bits.ACKEN = 1;
        while(SSPCON2bits.ACKEN);

    #elif defined (_18F26K42) || defined (_18F57Q43)

        I2C1CON1bits.ACKDT = Ack;   /* usefull ?? */

    #elif defined(__PIC24F__) || defined(__dsPIC33F__)

        if (bus_id == I2C_BUS_1){
            I2C1CONbits.ACKDT = Ack;
            I2C1CONbits.ACKEN = 1;
        }

        #ifdef _MI2C2IF
        else if (bus_id == I2C_BUS_2){
            I2C2CONbits.ACKDT = Ack;
            I2C2CONbits.ACKEN = 1;
        }
        #endif

    #elif defined(__PIC32MX__)

    #else

        #error -- processor ID not specified in generic header file

    #endif

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//------------------------ Reception of Acknowledge ---------------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_wait_ack(I2C_BUS bus_id)
{
    u8 i;
    #if defined (_18F252) || defined (_18LF252)

        /* wait for end of transaction */
        while (SSPSTATbits.R_W);            /* usefull ? */

        /* wait for ack reception */
        for (i = 0; i < 100; i++)
        {
            if (!SSPCON2bits.ACKSTAT)
            {
                return SUCCESS;
            }
        }
        PIR1bits.SSPIF = 0;   /* usefull ? */

    #elif defined (_18F26K42) || defined (_18F57Q43)

        /* wait for ack reception */
        for (i = 0; i < 100; i++)
        {
            if (!I2C1CON1bits.ACKSTAT)
            {
                return SUCCESS;
            }
        }

    #elif defined(__PIC24F__) || defined(__dsPIC33F__)

        if (bus_id == I2C_BUS_1){
            for (i = 0; i < 100; i++)
            {
                if (!I2C1STATbits.ACKSTAT)    // attendre reception du Ack du slave
                {
                    return SUCCESS;
                }
            }
        }

        #ifdef _MI2C2IF
        else if (bus_id == I2C_BUS_2){
            for (i = 0; i < 100; i++)
            {
                if (!I2C2STATbits.ACKSTAT)    // attendre reception du Ack du slave
                {
                    return SUCCESS;
                }
            }
        }
        #endif

    #elif defined(__PIC32MX__)

    #else

        #error -- processor ID not specified in generic header file

    #endif

    return ERROR;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//--------------------------- Read operation ----------------------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_read(I2C_BUS bus_id, u8 ack, u8 *data)
{
    /* wait for the bus to be free */
    if (_wait_for_idle(bus_id) != SUCCESS){
        i2c_stop(bus_id);
        return ERROR;
    }

    #if defined (_18F252) || defined (_18LF252)

        SSPCON2bits.RCEN = 1;
        while (!PIR1bits.SSPIF);
        PIR1bits.SSPIF = 0;
        i2c_send_ack(bus_id, ack);
        *data = SSPBUF;

    #elif defined (_18F26K42) || defined (_18F57Q43)

    #elif defined(__PIC24F__) || defined(__dsPIC33F__)

        if (bus_id == I2C_BUS_1){
            I2C1CONbits.RCEN = 1;           // enable receive
            I2C1STATbits.I2COV = 0;         // clear overflow flag
            i2c_send_ack(bus_id, ack);      // ack if it's not the last read, nack if it's the last
            *data = I2C1RCV;                // return received data
        }

        #ifdef _MI2C2IF
        else if (bus_id == I2C_BUS_2){
            I2C2CONbits.RCEN = 1;           // enable receive
            I2C2STATbits.I2COV = 0;         // clear overflow flag
            i2c_send_ack(bus_id, ack);      // ack if it's not the last read, nack if it's the last
            *data = I2C2RCV;                // return received data
        }
        #endif

    #elif defined(__PIC32MX__)

    #else

        #error -- processor ID not specified in generic header file

    #endif

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//--------------------------- Write operation ---------------------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_write(I2C_BUS bus_id, u8 data)
{
    /* wait for the bus to be free */
    // if (_wait_for_idle(bus_id) != SUCCESS){
    //     return ERROR;
    // }

    #if defined (_18F252) || defined (_18LF252)

        /* send data */
        SSPBUF = data;
        PIR1bits.SSPIF = 0;

    #elif defined (_18F26K42) || defined (_18F57Q43)

        I2C1CNT = 1;
        I2C1TXB = data;

    #elif defined(__PIC24F__) || defined(__dsPIC33F__)

        if (bus_id == I2C_BUS_1){
            /* send data */
            I2C1TRN = data;
        }

        #ifdef _MI2C2IF
        else if (bus_id == I2C_BUS_2){
            /* send data */
            I2C2TRN = data;

        }
        #endif

    #elif defined(__PIC32MX__)

        return ERROR;

    #else

        #error -- processor ID not specified in generic header file

    #endif

    /* wait for the reception of Ack */
    if (i2c_wait_ack(bus_id) != SUCCESS){
        i2c_stop(bus_id);
        return ERROR;
    }

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//------------------------- Send stop condition -------------------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_stop(I2C_BUS bus_id)
{
    #if defined (_18F252) || defined (_18LF252)

        SSPCON2bits.PEN = 1;
        while(SSPCON2bits.PEN);

    #elif defined (_18F26K42) || defined (_18F57Q43)

        /* nothing to do */

    #elif defined(__PIC24F__) || defined(__dsPIC33F__)

        if (bus_id == I2C_BUS_1){
            _wait_for_idle (bus_id);
            I2C1CONbits.PEN = 1;
        }

        #ifdef _MI2C2IF
        else if (bus_id == I2C_BUS_2){
            _wait_for_idle (bus_id);
            I2C2CONbits.PEN = 1;
        }
        #endif

    #elif defined(__PIC32MX__)

        StopI2C1();
        IdleI2C1();

    #else

        #error -- processor ID not specified in generic header file

    #endif

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//--------------------------------- Idle --------------------------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
static result_t _wait_for_idle(I2C_BUS bus_id)
{
    #if defined (_18F252) || defined (_18LF252)

        u16 timeout = 0;

        while (SSPCON2bits.RSEN ||
               SSPCON2bits.SEN ||
               SSPCON2bits.PEN ||
               SSPCON2bits.RCEN ||
               SSPSTATbits.R_W){
            timeout++;
            delay_us(1);
            if (timeout >= 500)
                return ERROR;
        }

    #elif defined (_18F26K42) || defined (_18F57Q43)

        while (!I2C1STAT0bits.BFRE);

    #elif defined(__PIC24F__) || defined(__dsPIC33F__)

        u16 timeout = 0;

        if (bus_id == I2C_BUS_1){
            while (I2C1CONbits.SEN ||
                   I2C1CONbits.PEN ||
                   I2C1CONbits.RCEN ||
                   I2C1CONbits.RSEN ||
                   I2C1CONbits.ACKEN ||
                   I2C1STATbits.TRSTAT){
                timeout++;
                delay_us(1);
                if (timeout >= 500)
                    return ERROR;
            };
        }

        #ifdef _MI2C2IF
        else if (bus_id == I2C_BUS_2){
            while (I2C2CONbits.SEN ||
                   I2C2CONbits.PEN ||
                   I2C2CONbits.RCEN ||
                   I2C2CONbits.RSEN ||
                   I2C2CONbits.ACKEN ||
                   I2C2STATbits.TRSTAT){
                timeout++;
                delay_us(1);
                if (timeout >= 500)
                    return ERROR;
            };
        }
        #endif

    #elif defined(__PIC32__)

        IdleI2C1();

    #else

        #error -- processor ID not specified in generic header file

    #endif

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//------------------------ Read a register of a device ------------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_read_reg(I2C_BUS bus_id, u8 dev_addr, u8 reg_addr, u8 *data)
{
    /* send start condition */
    if (i2c_start(bus_id) != SUCCESS)
        return ERROR;

    /* address of the chip + W */
    if (i2c_write(bus_id, I2C_ADDR_WR(dev_addr)) != SUCCESS)
        return ERROR;

    /* address of the register */
    if (i2c_write(bus_id, reg_addr) != SUCCESS)
        return ERROR;

    /* send restart condition */
    if (i2c_rstart(bus_id) != SUCCESS)
        return ERROR;

    /* next operation is a reading */
    if (i2c_write(bus_id, I2C_ADDR_RD(dev_addr)) != SUCCESS)
        return ERROR;

    /* get data */
    if (i2c_read(bus_id, I2C_NACK, data) != SUCCESS)
        return ERROR;

    /* send stop condition */
    if (i2c_stop(bus_id) != SUCCESS)
        return ERROR;

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//------------------------ Read N registers of a device -----------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_read_n_reg(I2C_BUS bus_id, u8 dev_addr, u8 reg_addr, u8 size, u8 *data)
{
    u8 i;

    /* send start condition */
    if (i2c_start(bus_id) != SUCCESS)
        return ERROR;

    /* address of the chip + W */
    if (i2c_write(bus_id, I2C_ADDR_WR(dev_addr)) != SUCCESS)
        return ERROR;

    /* address of the register */
    if (i2c_write(bus_id, reg_addr) != SUCCESS)
        return ERROR;

    /* send restart condition */
    if (i2c_rstart(bus_id) != SUCCESS)
        return ERROR;

    /* next operation is a reading */
    if (i2c_write(bus_id, I2C_ADDR_RD(dev_addr)) != SUCCESS)
        return ERROR;

    /* get data */
    for (i = 0; i < size; i++){
        if (i == size - 1){   /* last reading */
        // if (i < size){   /* last reading */
            if (i2c_read(bus_id, I2C_NACK, data + i) != SUCCESS){
                return ERROR;
            }
        }
        else{
            if (i2c_read(bus_id, I2C_ACK, data + i) != SUCCESS){
                return ERROR;
            }
        }
    }

    /* send stop condition */
    if (i2c_stop(bus_id) != SUCCESS)
        return ERROR;

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//--------------------- Write in a register of a device -----------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_write_reg(I2C_BUS bus_id, u8 dev_addr, u8 reg_addr, u8 data)
{
    /* send start condition */
    if (i2c_start(bus_id) != SUCCESS)
        return ERROR;

    /* address of the device + Write */
    if (i2c_write(bus_id, I2C_ADDR_WR(dev_addr)) != SUCCESS)
        return ERROR;

    /* address of the register */
    if (i2c_write(bus_id, reg_addr) != SUCCESS)
        return ERROR;

    /* write data*/
    if (i2c_write(bus_id, data) != SUCCESS)
        return ERROR;

    /* send stop condition */
    if (i2c_stop(bus_id) != SUCCESS)
        return ERROR;

    return SUCCESS;
}

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//---------------- Write N values in N registers of a device ------------------
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
result_t i2c_write_n_reg(I2C_BUS bus_id, u8 dev_addr, u8 reg_addr, u8 size, u8 *data)
{
    u8 i;

    /* send start condition */
    if (i2c_start(bus_id) != SUCCESS)
        return ERROR;

    /* address of the device + Write */
    if (i2c_write(bus_id, I2C_ADDR_WR(dev_addr)) != SUCCESS)
        return ERROR;

    /* address of the register */
    if (i2c_write(bus_id, reg_addr) != SUCCESS)
        return ERROR;

    /* write data*/
    for (i = 0; i < size; i++){
        if (i2c_write(bus_id, data[i]) != SUCCESS)
            return ERROR;
    }

    /* send stop condition */
    if (i2c_stop(bus_id) != SUCCESS)
        return ERROR;

    return SUCCESS;
}
