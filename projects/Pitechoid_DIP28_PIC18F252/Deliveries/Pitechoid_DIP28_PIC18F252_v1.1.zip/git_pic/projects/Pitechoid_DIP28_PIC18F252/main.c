/******************************************************************************
* Title:    Evaluation board for 18F252
* MCU:      18F252
*******************************************************************************
* Versions: v1.0    01/08/2014  MPLAB: vx.x   XC8: vx.x
*                   Initial version
*           v1.1    08/08/2026  MPLAB: v6.20  XC8: v3.10
*                   Reworked most drivers
******************************************************************************/

/******************************************************************************
* Remove useless warnings
******************************************************************************/
#pragma warning disable 520     // function is never called
#pragma warning disable 759     // expression generates no code
#pragma warning disable 1311    // missing configuration setting
#pragma warning disable 1498    // pointer in expression may have no targets
#pragma warning disable 1510    // non-reentrant function
#pragma warning disable 2020

/******************************************************************************
* Includes
******************************************************************************/
#include "config.h"
#include "xc.h"
#include "stdio.h"
#include "hardware_profile.h"

#include "bcd.h"
#include "bh1750.h"
#include "ccp.h"
// #include "console.h"
#include "date_time.h"
#include "delays.h"
#include "ds1307.h"
#include "ds1631.h"
#include "eeprom_i2c.h"
#include "i2c.h"
#include "i2c_tools.h"
#include "interrupts.h"
#include "io.h"
#include "lcd_hd44780.h"
#include "log.h"
#include "mma7660.h"
#include "pcf8574.h"
#include "pin_manager.h"
#include "pwm.h"
#include "timer.h"
#include "tmp75.h"
#include "types.h"
#include "uart.h"


/******************************************************************************
* Defines
******************************************************************************/
#define DEBOUNCE_DELAY  100


/*****************************************************************************
* Global variables
******************************************************************************/
bool_t time_has_changed_timer = FALSE;
UART_ID UART_ID_LOG = UART_ID_1;
const u8 pcf8574_values[14] = {
    0b01111111,
    0b10111111,
    0b11011111,
    0b11101111,
    0b11110111,
    0b11111011,
    0b11111101,
    0b11111110,
    0b11111101,
    0b11111011,
    0b11110111,
    0b11101111,
    0b11011111,
    0b10111111,
};


/******************************************************************************
* Main program
******************************************************************************/
void main (void)
{
    u8 i, j;
    u8 cnt = 0;
    float light;
    s8 x = 0; s8 y = 0; s8 z = 0;
    date_time_t t = {
        .hrs = 18,
        .min = 16,
        .sec =  0,
        .dow =  6,
        .day = 26,
        .mth = 07,
        .yrs = 26
    };
    LCD_HD44780_CONFIG_t lcd_hd44780_config = {
        .nb_lines = LCD_HD44780_NB_LINES_2,
        .nb_bits = LCD_HD44780_NB_BITS_4,
        .shift = LCD_HD44780_SHIFT_RIGHT
    };
    float tmp75_temp;
    float ds1631_temp = -12.5;
    u8 eeprom_data = 0x55;
    u32 eeprom_addr = 0x00;
    UART_CFG_t uart_1_cfg = {
        .uart_id = UART_ID_1,
        .baudrate = UART_FREQ,
        .system_clock = GetSystemClock()
    };
    I2C_CFG_t i2c_1_cfg = {
        .bus_id = I2C_BUS_1,
        .freq = I2C_FREQ,
        .slave_or_master = I2C_MASTER,
        .en_master_it = 0,
        .en_slave_it = 0,
        .slave_addr = 0x00
    };
    TIMER_CFG_t timer_0_cfg = {
        .timer_id = TIMER_ID_0, /* max period = 6.7 sec */
        .timer_prescaler = 7,
        .period = 65535         /* max = 65535 */
    };
    TIMER_CFG_t timer_1_cfg = { /* max period = 209 ms */
        .timer_id = TIMER_ID_1,
        .timer_prescaler = 3,
        .period = 65535         /* max = 65535 */
    };
    TIMER_CFG_t timer_2_cfg = {
        .timer_id = TIMER_ID_2, /* max period 26 ms */
        .timer_prescaler = 0,
        .timer_postscaler = 9,
        .period = 250           /* max = 255 */
    };
    TIMER_CFG_t timer_3_cfg = { /* max period = 209 ms */
        .timer_id = TIMER_ID_3,
        .timer_prescaler = 3,
        .period = 65535         /* max = 65535 */
    };

//--------------------------------- GPIO init ---------------------------------
    pin_manager_init();

    /* default values */
    PIN_LED_ERROR = 0;
    PIN_LED_SEC = 0;

//----------------------------------- UART ------------------------------------
    /* At 10 MHz the actual bitrate is 125k. Putty must be set to 125000
       or a 11.0592 MHz crystal must be used otherwise it won't work */
    if (uart_init(&uart_1_cfg) != SUCCESS){
        LOG_ERROR("UART initialization failed");
        PIN_LED_ERROR = 1;
    }
    printf("\nCoucou \n");

//--------------------- i2c, bus & devices initialization ---------------------
    if (i2c_init(&i2c_1_cfg) != SUCCESS){
        LOG_ERROR("I2C initialization failed");
        PIN_LED_ERROR = 1;
    }

    i2c_detect(I2C_BUS_1);

//-------------------------- Interruption sur Timer 2 -------------------------
    timer_init(&timer_0_cfg);
    timer_init(&timer_1_cfg);
    timer_init(&timer_2_cfg);   /* period = 400 ns * Presc(1) * Post(10) * Timer(250) * Cnt(1000) = 1s */
    timer_init(&timer_3_cfg);

//---------------- 3-Axis Orientation/Motion/Detection Sensor -----------------
    mma7660_init(I2C_BUS_1, I2C_ADR_MMA7660);

//------------------------ CCP Configuration (PWM mode) -----------------------
    // if (ccp_init(CCP_ID_1, TIMER_ID_2, 0/*freq*/, 255/*duty*/) != SUCCESS){
    //     LOG_ERROR("CCP #1 initialization failed");
    //     PIN_LED_ERROR = 1;
    // }
    // ccp_set_pwm_duty(CCP_ID_1, 512);

    // if (ccp_init(CCP_ID_2, TIMER_ID_4, 0/*freq*/, 255/*duty*/) != SUCCESS){
    //     LOG_ERROR("CCP #2 initialization failed");
    //     PIN_LED_ERROR = 1;
    // }
    // ccp_set_pwm_duty(CCP_ID_2, 512);

    // if (ccp_init(CCP_ID_3, TIMER_ID_2, 0/*freq*/, 255/*duty*/) != SUCCESS){
    //     LOG_ERROR("CCP #3 initialization failed");
    //     PIN_LED_ERROR = 1;
    // }
    // ccp_set_pwm_duty(CCP_ID_3, 512);

    // if (ccp_init(CCP_ID_4, TIMER_ID_2, 0/*freq*/, 255/*duty*/) != SUCCESS){
    //     LOG_ERROR("CCP #4 initialization failed");
    //     PIN_LED_ERROR = 1;
    // }
    // ccp_set_pwm_duty(CCP_ID_4, 512);

//--------------------------------- LCD Init ----------------------------------
    lcd_hd44780_init(&lcd_hd44780_config);

//------------------------------------ RTC ------------------------------------
    if (ds1307_init(I2C_BUS_1, I2C_ADR_DS1307) != SUCCESS){
        LOG_ERROR("DS1307 initialization failed");
        PIN_LED_ERROR = 1;
    }
    if (ds1307_set_time(I2C_BUS_1, I2C_ADR_DS1307, t) != SUCCESS){
        LOG_ERROR("Unable to set RTC date & time");
        PIN_LED_ERROR = 1;
    }
    if (ds1307_get_time(I2C_BUS_1, I2C_ADR_DS1307, &t) != SUCCESS){
        LOG_ERROR("Unable to get RTC date & time");
        PIN_LED_ERROR = 1;
    }

//---------------------------------- Sensors ----------------------------------
    if (tmp75_configure(I2C_BUS_1, I2C_ADR_TMP75) != SUCCESS){
        LOG_ERROR("TMP75 initialization failed");
        PIN_LED_ERROR = 1;
    }

    if (bh1750_init(I2C_BUS_1, I2C_ADR_BH1750) != SUCCESS){
        LOG_ERROR("BH1750 initialization failed");
        PIN_LED_ERROR = 1;
    }

    /* Configure DS1631 in continuous mode */
    if (ds1631_config(I2C_BUS_1, I2C_ADR_DS1631, DS1631_CFG_RES_12B | DS1631_CFG_CONTINUOUS) == SUCCESS){
        /* start temperature conversion */
        if (ds1631_start_conv(I2C_BUS_1, I2C_ADR_DS1631) != SUCCESS)
        {
            PIN_LED_ERROR = 1;
        }
    }else{
        LOG_ERROR("DS1631 initialization failed");
        PIN_LED_ERROR = 1;
    }

    //---------------------------------- EEPROM ----------------------------------
    // if (eeprom_i2c_write_byte(I2C_BUS_1, &EEPROM_24LC1025, I2C_ADR_EEPROM, 0x00008, 0x23) != SUCCESS){
    //     LOG_ERROR("Unable to write to EEPROM");
    //     PIN_LED_ERROR = 1;
    // }

    // if (eeprom_i2c_write_byte(I2C_BUS_1, &EEPROM_24LC1025, I2C_ADR_EEPROM, 0x00010, 0x5A) != SUCCESS){
    //     LOG_ERROR("Unable to write to EEPROM");
    //     PIN_LED_ERROR = 1;
    // }

//----------------------------- Global Interrupts -----------------------------
    enable_global_interrupts();

//-----------------------------------------------------------------------------
    while (1){
        delay_ms(100);

        lcd_hd44780_write_time(t, LCD_HD44780_LINE_1, 1/*position*/);
        lcd_hd44780_write_date(t, LCD_HD44780_LINE_2, 1/*position*/, LCD_HD44780_DATE_LETTERS);

        ds1631_read_temp(I2C_BUS_1, I2C_ADR_DS1631, &ds1631_temp);
        lcd_hd44780_write_temperature(ds1631_temp, LCD_HD44780_LINE_1, 11/*position*/);

        tmp75_read_temp(I2C_BUS_1, I2C_ADR_TMP75, &tmp75_temp);
        lcd_hd44780_write_temperature(tmp75_temp, LCD_HD44780_LINE_2, 11/*position*/);

        bh1750_get_light(I2C_BUS_1, I2C_ADR_BH1750, &light);

        mma7660_read_angles(I2C_BUS_1, I2C_ADR_MMA7660, &x, &y, &z);

        // if(eeprom_i2c_read_byte(I2C_BUS_1, &EEPROM_24LC1025, I2C_ADR_EEPROM, eeprom_addr, &eeprom_data) != SUCCESS){
        //     LOG_ERROR("Unable to read from EEPROM");
        //     PIN_LED_ERROR = 1;
        // }else{
        //     LOG_INFO("EEPROM: Addr=0x%08lX Data=0x%02X    ", eeprom_addr, eeprom_data);
        // }
        // eeprom_addr++;

        if (time_has_changed_timer){
            time_has_changed_timer = FALSE;
            datetime_increase_seconds(&t);
            printf("Time: %02d:%02d:%02d   ", t.hrs, t.min, t.sec);
            printf("Temp(DS1631): %2.1fC   ", ds1631_temp);
            printf("Temp(TMP75): %2.1fC   ", tmp75_temp);
            printf("Light: %2.1f lx    ",  light);
            printf("MMA7660: X=%d, Y=%d, Z=%d", x, y, z);
            printf("\r\n");
            pcf8574_write_port(I2C_BUS_1, I2C_ADR_PCF8574A, pcf8574_values[cnt]);
            if (++cnt > 13) cnt = 0;
        }

        if (!PIN_SWITCH_1){
            delay_ms(25);
            if (!PIN_SWITCH_1){
                datetime_increase_minutes(&t);
            }
        }

        if (!PIN_SWITCH_2){
            delay_ms(25);
            if (!PIN_SWITCH_2){
                datetime_decrease_minutes(&t);
            }
        }
    }

}

